package com.atguigu.spring.annotation.generic;

public class User {

}
