package com.atguigu.spring.annotation.generic;

import org.springframework.stereotype.Service;

@Service
public class RoleService extends BaseService<Role>{

}
