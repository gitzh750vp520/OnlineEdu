package com.atguigu.spring.annotation.generic;

public class Role {

}
